#include <iostream>
#include <string>
#include <boost/asio.hpp>
#include <stdexcept>
#include "server.h"
#include "Conn_handler.h"

namespace asio = boost::asio;
namespace ip = asio::ip;
using namespace nlohmann;

int main(int argc, char* argv[])
{

    try
    {
        asio::io_context io_context;
        Server server(io_context, 5000);
        io_context.run();
    }
    catch (std::exception& e)
    {
        std::cerr << e.what() << std::endl;
    }
    return 0;
}
