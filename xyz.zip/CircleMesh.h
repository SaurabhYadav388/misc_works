#pragma once
#include "MeshObject.h"
ref class CircleMesh : public MeshObject
{
internal:
    CircleMesh(_In_ ID3D11Device* device, uint32 segments);
};


