#include "pch.h"
#include "CircleMesh.h"
#include "DirectXSample.h"
#include "ConstantBuffers.h"

using namespace Microsoft::WRL;
using namespace DirectX;

CircleMesh::CircleMesh(_In_ ID3D11Device* device, uint32 segments)
{
    D3D11_BUFFER_DESC bd = { 0 };
    D3D11_SUBRESOURCE_DATA initData = { 0 };

    uint32 numVertices = 2 * (segments+1);//6 * (segments + 1) + 1;
    uint32 numIndices = 3 * segments;//3 * segments * 3 * 2;

    std::vector<PNTVertex> point(numVertices);
    std::vector<uint16> index(numIndices);

    uint32 p = 0;
    // Top center point (multiple points for texture coordinates).
    for (uint32 a = 0; a <= segments; a++)
    {
        point[p].position = XMFLOAT3(0.0f, 0.0f, 1.0f);///////////////
        point[p].normal = XMFLOAT3(0.0f, 0.0f, 1.0f);
        point[p].textureCoordinate = XMFLOAT2(static_cast<float>(a) / static_cast<float>(segments), 0.0f);
        p++;
    }
    // Top edge of cylinder: Normals point up for lighting of top surface.
    for (uint32 a = 0; a <= segments; a++)
    {
        float angle = static_cast<float>(a) / static_cast<float>(segments) * XM_2PI;
        point[p].position = XMFLOAT3(cos(angle), sin(angle), 1.0f);/////////////////////
        point[p].normal = XMFLOAT3(0.0f, 0.0f, 1.0f);
        point[p].textureCoordinate = XMFLOAT2(static_cast<float>(a) / static_cast<float>(segments), 0.0f);
        p++;
    }
    //need to handle #ver & #ind to add this
    ////Top edge of cylinder: Normals point out for lighting of the side surface.
    //for (uint32 a = 0; a <= segments; a++)
    //{
    //    float angle = static_cast<float>(a) / static_cast<float>(segments) * XM_2PI;
    //    point[p].position = XMFLOAT3(cos(angle), sin(angle), -6.8f);
    //    point[p].normal = XMFLOAT3(cos(angle), sin(angle), 0.0f);
    //    point[p].textureCoordinate = XMFLOAT2(static_cast<float>(a) / static_cast<float>(segments), 0.0f);
    //    p++;
    //}
    
    m_vertexCount = p;

    p = 0;
    for (int a=0;a<segments;a++)
    {
        index[p] = a;
        index[p+1] = a+segments+1;
        index[p+2]= a+segments+2;
        p += 3;
    }

    m_indexCount = p;

    bd.Usage = D3D11_USAGE_DEFAULT;
    bd.ByteWidth = sizeof(PNTVertex) * m_vertexCount;
    bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
    bd.CPUAccessFlags = 0;
    initData.pSysMem = point.data();
    DX::ThrowIfFailed(
        device->CreateBuffer(&bd, &initData, &m_vertexBuffer)
    );

    bd.Usage = D3D11_USAGE_DEFAULT;
    bd.ByteWidth = sizeof(uint16) * m_indexCount;
    bd.BindFlags = D3D11_BIND_INDEX_BUFFER;
    bd.CPUAccessFlags = 0;
    initData.pSysMem = index.data();
    DX::ThrowIfFailed(
        device->CreateBuffer(&bd, &initData, &m_indexBuffer)
    );
}