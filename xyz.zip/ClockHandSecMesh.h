#pragma once
#include "MeshObject.h"
ref class ClockHandSecMesh : public MeshObject
{
internal:
    ClockHandSecMesh(_In_ ID3D11Device* device);
};
