const jwt = require("jsonwebtoken");

function GenerateToken(player)
{
    return jwt.sign(
        {
            playerId: player.playerId,
            eosPuid: player.eosPuid
        },
        process.env.JWT_SECRET,
        {
            expiresIn: "24h"
        });
}

module.exports =
{
    GenerateToken
};