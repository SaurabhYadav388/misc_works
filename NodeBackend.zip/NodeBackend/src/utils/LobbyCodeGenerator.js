const crypto = require("crypto");

const CHARACTERS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function GenerateLobbyCode(length = 3)
{
    let code = "";

    const randomBytes =
        crypto.randomBytes(length);

    for(let i = 0; i < length; i++)
    {
        code +=
            CHARACTERS[
                randomBytes[i] %
                CHARACTERS.length
            ];
    }

    return code;
}

module.exports =
{
    GenerateLobbyCode
};