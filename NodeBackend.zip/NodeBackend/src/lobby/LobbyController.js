const LobbyService =
    require("./LobbyService");

async function CreateLobby(req,res)
{
    const result =
        await LobbyService.CreateLobby(
            req.player.playerId,
            req.body);

    if(!result.success)
    {
        return res
            .status(400)
            .json(result);
    }

    res.status(201).json(result);
}
async function GetLobbies(req,res)
{
    const result =
        await LobbyService.GetLobbies();

    res.json(result);
}

async function JoinLobby(req,res)
{
    const result =
        await LobbyService.JoinLobby(
            req.player.playerId,
            req.params.id);

    if(!result.success)
    {
        return res
            .status(400)
            .json(result);
    }

    res.json(result);
}

async function LeaveLobby(req, res)
{
    const result =
        await LobbyService.LeaveLobby(
            req.player.playerId);

    if (!result.success)
    {
        return res.status(400).json(result);
    }

    return res.json(result);
}

module.exports =
{
    CreateLobby,
    GetLobbies,
    JoinLobby,
    LeaveLobby
};