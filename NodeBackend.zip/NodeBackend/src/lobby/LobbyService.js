const crypto = require("crypto");

const Registry = require("../registry/Registry");
const Result = require("../shared/Result");
const Constants = require("../shared/Constants");
const LobbyCodeGenerator = require("../utils/LobbyCodeGenerator");

async function CreateLobby(ownerId, request)
{
    const owner =
        Registry.getPlayer(ownerId);

    if(!owner)
    {
        return Result.Failure(
            "PLAYER_NOT_FOUND",
            "Player does not exist.");
    }
    if(owner.currentLobbyId)
    {
        return Result.Failure(
            "PLAYER_ALREADY_IN_LOBBY",
            "Player already belongs to a lobby.");
    }

    const lobby =
    {
        lobbyId: crypto.randomUUID(),
        lobbyCode: LobbyCodeGenerator.GenerateLobbyCode(),
        name: request.name,
        map: request.map,
        maxPlayers: request.maxPlayers,
        ownerId: owner.playerId,
        state: Constants.LobbyStates.WAITING,
        createdAt: new Date(),
        members:
        [
            {
                playerId: owner.playerId,
                displayName: owner.displayName,
                isLeader: true,
                joinedAt: new Date()
            }
        ]
    };

    Registry.addLobby(lobby);
    owner.state = Constants.PlayerStates.IN_LOBBY;
    owner.currentLobbyId = lobby.lobbyId;

    return Result.Success(lobby);
}

async function GetLobbies()
{
    const lobbies = Registry.getAllLobbies();

    const response =
        lobbies.map(lobby =>
        ({
            lobbyId: lobby.lobbyId,

            lobbyCode:lobby.lobbyCode,

            name: lobby.name,

            map: lobby.map,

            currentPlayers: lobby.members.length,

            maxPlayers: lobby.maxPlayers,

            state: lobby.state
        }));

    return Result.Success(response);
}

async function JoinLobby(playerId,lobbyId)
{
    const player =
        Registry.getPlayer(playerId);

    if(!player)
    {
        return Result.Failure(
            "PLAYER_NOT_FOUND",
            "Player does not exist.");
    }

    const lobby =
        Registry.getLobby(lobbyId);

    if(!lobby)
    {
        return Result.Failure(
            "LOBBY_NOT_FOUND",
            "Lobby not found.");
    }

    if(player.currentLobbyId)
    {
        return Result.Failure(
            "PLAYER_ALREADY_IN_LOBBY",
            "Player already belongs to a lobby.");
    }

    if(lobby.members.length >= lobby.maxPlayers)
    {
        return Result.Failure(
            "LOBBY_FULL",
            "Lobby is already full.");
    }

    lobby.members.push(
    {
        playerId:
            player.playerId,

        displayName:
            player.displayName,

        isLeader:false,

        joinedAt:new Date()
    });

    player.state =
        Constants.PlayerStates.IN_LOBBY;

    return Result.Success(
    {
        lobbyId:lobby.lobbyId,

        currentPlayers:
            lobby.members.length,

        maxPlayers:
            lobby.maxPlayers
    });
}

async function LeaveLobby(playerId)
{
    const player = Registry.getPlayer(playerId);

    if (!player)
    {
        return Result.Failure(
            "PLAYER_NOT_FOUND",
            "Player not found.");
    }

    if (!player.currentLobbyId)
    {
        return Result.Failure(
            "PLAYER_NOT_IN_LOBBY",
            "Player is not inside a lobby.");
    }

    const lobby =
        Registry.getLobby(player.currentLobbyId);

    if (!lobby)
    {
        player.currentLobbyId = null;
        player.state =
            Constants.PlayerStates.AUTHENTICATED;

        return Result.Failure(
            "LOBBY_NOT_FOUND",
            "Lobby not found.");
    }

    //----------------------------------
    // OWNER LEFT
    //----------------------------------

    if (lobby.ownerId === playerId)
    {
        // Reset every member
        for (const member of lobby.members)
        {
            const lobbyPlayer =
                Registry.getPlayer(member.playerId);

            if (lobbyPlayer)
            {
                lobbyPlayer.currentLobbyId = null;
                lobbyPlayer.state =
                    Constants.PlayerStates.AUTHENTICATED;
            }
        }

        Registry.removeLobby(lobby.lobbyId);

        return Result.Success({
            action: "LobbyClosed"
        });
    }

    //----------------------------------
    // NORMAL PLAYER LEFT
    //----------------------------------

    lobby.members =
        lobby.members.filter(
            m => m.playerId !== playerId);

    player.currentLobbyId = null;

    player.state =
        Constants.PlayerStates.AUTHENTICATED;

    // Safety
    if (lobby.members.length === 0)
    {
        Registry.removeLobby(lobby.lobbyId);

        return Result.Success({
            action: "LobbyClosed"
        });
    }

    return Result.Success({
        action: "LobbyUpdated",
        lobby: lobby
    });
}

module.exports =
{
    CreateLobby,
    GetLobbies,
    JoinLobby,
    LeaveLobby
};