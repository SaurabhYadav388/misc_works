const express = require("express");
const cors = require("cors");

const AuthRoutes = require("./routes/AuthRoutes");

const app = express();

app.use(cors());

app.use(express.json());

app.use("/auth", AuthRoutes);

module.exports = app;