const express = require("express");
const cors = require("cors");

const AuthRoutes = require("./routes/AuthRoutes");
const LobbyRoutes = require("./routes/LobbyRoutes");

const app = express();

app.use(cors());

app.use(express.json());

app.use("/auth", AuthRoutes);
app.use("/lobbies",LobbyRoutes);

module.exports = app;