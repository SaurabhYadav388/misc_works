class Registry
{
    constructor()
    {
        this.players = new Map();
        this.lobbies = new Map();
    }

    //-------------------
    // Player
    //-------------------

    addPlayer(player)
    {
        this.players.set(player.playerId, player);
    }

    getPlayer(playerId)
    {
        return this.players.get(playerId);
    }

    getPlayerByEOSPuid(eosPuid)
    {
        for(const player of this.players.values())
        {
            if(player.eosPuid === eosPuid)
            {
                return player;
            }
        }

        return null;
    }

    removePlayer(playerId)
    {
        this.players.delete(playerId);
    }

    getPlayers()
    {
        return [...this.players.values()];
    }

    //-------------------
    // Lobby
    //-------------------

    addLobby(lobby)
    {
        this.lobbies.set(lobby.lobbyId, lobby);
    }

    getLobby(lobbyId)
    {
        return this.lobbies.get(lobbyId);
    }

    removeLobby(lobbyId)
    {
        this.lobbies.delete(lobbyId);
    }

    getAllLobbies()
    {
        return [...this.lobbies.values()];
    }
    
    getLobbyByOwner(ownerId)
    {
        for(const lobby of this.lobbies.values())
        {
            if(lobby.ownerId === ownerId)
            {
                return lobby;
            }
        }

        return null;
    }

    isPlayerInLobby(playerId)
    {
        for(const lobby of this.lobbies.values())
        {
            if(lobby.members.some(m => m.playerId === playerId))
            {
                return true;
            }
        }

        return false;
    }
    getLobbyByCode(code)
    {
        for(const lobby of this.lobbies.values())
        {
            if(lobby.lobbyCode === code)
            {
                return lobby;
            }
        }

        return null;
    }
}

module.exports = new Registry();