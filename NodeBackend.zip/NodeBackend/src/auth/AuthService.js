const crypto = require("crypto");
const Registry = require("../registry/Registry");
const JwtHelper = require("../utils/JwtHelper");

const Result = require("../shared/Result");

const EOSProvider = require("./providers/MockEOSProvider");

async function Login(eosAccessToken)
{
    const eosPlayer =
        await EOSProvider.VerifyToken(eosAccessToken);

    if (!eosPlayer)
    {
        return Result.Failure("AUTH_FAILED","EOS verification failed.");
    }

    const player =
    {
        playerId: crypto.randomUUID(),
        eosPuid: eosPlayer.eosPuid,
        displayName: eosPlayer.displayName,
        state: "Authenticated"
    };

    player.jwt = JwtHelper.GenerateToken(player);

    Registry.addPlayer(player);

    return Result.Success({
        jwt: player.jwt,

        player:
        {
            playerId: player.playerId,
            displayName: player.displayName
        }
    });
}

module.exports =
{
    Login
};