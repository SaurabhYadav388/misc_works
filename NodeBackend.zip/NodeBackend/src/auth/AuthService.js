const crypto = require("crypto");

const Registry = require("../registry/Registry");
const JwtHelper = require("../utils/JwtHelper");
const Result = require("../shared/Result");
const Constants = require("../shared/Constants");

const EOSProvider = require("./providers/MockEOSProvider");

async function Login(eosAccessToken)
{
    const eosPlayer = await EOSProvider.VerifyToken(eosAccessToken);

    if (!eosPlayer)
    {
        return Result.Failure(
            "AUTH_FAILED",
            "EOS verification failed."
        );
    }

    // Check if player already exists
    let player = Registry.getPlayerByEOSPuid(eosPlayer.eosPuid);

    if (player)
    {
        // Existing player -> Generate fresh JWT
        player.jwt = JwtHelper.GenerateToken(player);

        return Result.Success({
            jwt: player.jwt,

            player:
            {
                playerId: player.playerId,
                displayName: player.displayName
            }
        });
    }

    // First time login
    player =
    {
        playerId: crypto.randomUUID(),

        eosPuid: eosPlayer.eosPuid,

        displayName: eosPlayer.displayName,

        state: Constants.PlayerStates.AUTHENTICATED,

        currentLobbyId: null,

        currentMatchId: null
    };

    player.jwt = JwtHelper.GenerateToken(player);

    Registry.addPlayer(player);

    return Result.Success({
        jwt: player.jwt,

        player:
        {
            playerId: player.playerId,
            displayName: player.displayName
        }
    });
}

module.exports =
{
    Login
};