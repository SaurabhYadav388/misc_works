const AuthService = require("./AuthService");

async function Login(req, res)
{
    const result =
        await AuthService.Login(
            req.body.eosAccessToken);

    if (!result.success)
    {
        return res.status(401).json(result);
    }

    res.json(result);
}

module.exports =
{
    Login
};