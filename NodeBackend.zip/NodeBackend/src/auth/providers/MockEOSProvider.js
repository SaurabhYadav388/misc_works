const crypto = require("crypto");

async function VerifyToken(eosAccessToken)
{
    if (!eosAccessToken)
    {
        return null;
    }

    return {
        eosPuid: crypto.randomUUID(),
        displayName: "TestPlayer"
    };
}

module.exports =
{
    VerifyToken
};