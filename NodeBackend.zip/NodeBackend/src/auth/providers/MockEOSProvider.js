const crypto = require("crypto");

async function VerifyToken(eosAccessToken)
{
    if (!eosAccessToken)
    {
        return null;
    }

    return {
        eosPuid: eosAccessToken,
        displayName: `Player_${eosAccessToken}`
    };
}

module.exports =
{
    VerifyToken
};