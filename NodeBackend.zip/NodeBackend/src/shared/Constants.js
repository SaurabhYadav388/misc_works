const Constants =
{
    PlayerStates:
    {
        OFFLINE: "Offline",
        AUTHENTICATED: "Authenticated",
        IN_LOBBY: "InLobby",
        LOADING: "Loading",
        IN_MATCH: "InMatch"
    },

    LobbyStates:
    {
        WAITING: "Waiting",
        READY: "Ready",
        ALLOCATING: "Allocating",
        DESTROYED: "Destroyed"
    },

    MatchStates:
    {
        CREATED: "Created",
        WAITING_SERVER: "WaitingServer",
        LOADING: "Loading",
        READY: "Ready",
        RUNNING: "Running",
        FINISHED: "Finished"
    },

    ServerStates:
    {
        OFFLINE: "Offline",
        STARTING: "Starting",
        REGISTERING: "Registering",
        IDLE: "Idle",
        ASSIGNED: "Assigned",
        RUNNING: "Running",
        STOPPING: "Stopping"
    }
};

module.exports = Constants;