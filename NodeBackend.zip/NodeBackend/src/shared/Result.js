class Result
{
    static Success(data = null)
    {
        return {
            success: true,
            data
        };
    }

    static Failure(code, message)
    {
        return {
            success: false,
            error:
            {
                code,
                message
            }
        };
    }
}

module.exports = Result;