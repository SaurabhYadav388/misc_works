const jwt = require("jsonwebtoken");

const Registry = require("../registry/Registry");

module.exports =
function(req,res,next)
{
    const auth =
        req.headers.authorization;

    if(!auth)
    {
        return res.sendStatus(401);
    }

    const token =
        auth.split(" ")[1];

    try
    {
        const payload =
            jwt.verify(
                token,
                process.env.JWT_SECRET);

        const player =
            Registry.getPlayer(
                payload.playerId);

        if(!player)
        {
            return res.sendStatus(401);
        }

        req.player = player;

        next();
    }
    catch
    {
        return res.sendStatus(401);
    }
}