const express = require("express");

const router = express.Router();

const AuthController = require("../auth/AuthController");

router.post("/login", AuthController.Login);

module.exports = router;