const express = require("express");

const router =
    express.Router();

const Auth = require("../middleware/AuthMiddleware");

const LobbyController = require("../lobby/LobbyController");

router.post( "/",Auth,LobbyController.CreateLobby);
router.get("/",Auth,LobbyController.GetLobbies);
router.post("/:id/join",Auth,LobbyController.JoinLobby);
router.post("/leave",Auth,LobbyController.LeaveLobby);
module.exports = router;