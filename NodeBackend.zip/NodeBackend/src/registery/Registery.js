class Registry
{
    constructor()
    {
        this.players = new Map();
    }

    addPlayer(player)
    {
        this.players.set(player.playerId, player);
    }

    getPlayer(playerId)
    {
        return this.players.get(playerId);
    }

    removePlayer(playerId)
    {
        this.players.delete(playerId);
    }

    getPlayers()
    {
        return [...this.players.values()];
    }
}

module.exports = new Registry();