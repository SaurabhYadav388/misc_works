#pragma once
#include <iostream>
#include <string>

template <typename T>
class Matrix
{

	int row;
	int col;
	T** data;

public:

	Matrix(int row, int col)
    {
        this->row = row;
        this->col = col;
        data = new T * [row];

        for (int i = 0;i < row;i++)
        {
            data[i] = new T[col];
            for (int j = 0;j < col;j++)
            {
                data[i][j] = 0;
            }
        }
    }
	int get_row()
    {
        return row;
    }

    void set_row(int new_row)
    {
        row = new_row;
    }

	int get_column()
    {
        return col;
    }

    void set_column(int new_column)
    {
        col = new_column;
    }

    void enter_Element()
    {
        std::cout << "\tEnter Cell Values : ";
        for (int i = 0;i < row;i++)
        {
            for (int j = 0;j < col;j++)
            {
                std::cin >> data[i][j];
            }
        }
    }

    
    void print()
    {
        for (int i = 0;i < row;i++)
        {
            std::cout << "\t";
            for (int j = 0;j < col;j++)
            {
                std::cout << data[i][j] << " ";
            }
            std::cout << '\n';
        }
    }

    //Transpose of the matrix
    Matrix<T> transpose()
    {
        Matrix<T> temp(col, row);

        for (int i = 0;i < row;i++)
        {
            for (int j = 0; j < col;j++)
            {
                temp[j][i] = data[i][j];
            }
        }
        return temp;
    }

    // "data" data member access directly using matrix_name[i][j]
    T* operator[](int row_index)
    {
        try
        {
            if(row_index >= row)
            {
                throw("index out of bound");
            }
        }
        catch (const std::string error)
        {
            std::cerr
                << error
                << "accessed row is not present"
                << std::endl;

        }
        return data[row_index];
    }
};

//matrix multiplication
template <typename T>
Matrix<T> operator*(Matrix<T> A, Matrix<T> B) // for Two matrix
{
    Matrix<T> temp(A.get_row(), B.get_column());
    try
    {
        if (A.get_column() != B.get_row())
        {
            throw("Matrix Multiplication not Applicable!");
        }
    }
    catch (const std::string error)
    {
        std::cerr
            << error
            << std::endl;
        return temp;
    }

    for (int k = 0; k < B.get_column();k++)
    {
        for (int i = 0;i < A.get_row();i++)
        {
            for (int j = 0;j < A.get_column();j++)
            {
                temp[i][k] += A[i][j] * B[j][k];
            }
        }
    }

    return temp;
}


//scalar multiplication
template <typename T>
Matrix<T> operator*(Matrix<T> A, int scalar) 
{
    Matrix<T> temp(A.get_row(), A.get_column());
    for (int i = 0;i < A.get_row();i++)
    {
        for (int j = 0;j < A.get_column();j++)
        {
            temp[i][j] = A[i][j] * scalar;
        }
    }
    return temp;
}

