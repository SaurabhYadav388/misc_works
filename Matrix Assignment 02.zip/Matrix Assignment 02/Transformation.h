#pragma once
#include "Matrix.h"

template <typename T>
class Transformation
{
public:

	static Matrix<T> translate_3d(Matrix<T>&, T, T, T);
	static Matrix<T> scaling_3d(Matrix<T>&, T, T, T);
	static Matrix<T> skewing_3d(Matrix<T>&, char, T, T);
};

//translate the matrix
template <typename T>
Matrix<T> Transformation<T>::translate_3d(Matrix<T>& matrix, T x_offset, T y_offset, T z_offset )
{
	int row_size = matrix.get_row();
	int col_size = matrix.get_column();

	try {
		if (row_size != 3)
		{
			throw(" Each point to translate should have three coordinates for 3D transform");
		}
	}
	catch (const std::string error)
	{
		std::cerr
			<< error
			<< std::endl;
	}


	Matrix<T> result(row_size + 1, col_size);
	for (int row = 0; row < row_size; row++)
	{
		for (int col = 0; col < col_size; col++)
		{
			result[row][col] = matrix[row][col];
		}
	}
	for (int col = 0; col < col_size; col++)
	{
		result[row_size][col] = 1;
	}


	Matrix<T> translation_matrix(row_size + 1, row_size + 1);
	for (int row = 0; row < row_size + 1; row++)
	{
		for (int col = 0; col < row_size + 1; col++)
		{
			if (row == col)
			{
				translation_matrix[row][col] = 1;
			}
		}
		translation_matrix[row][row_size] = row == 0 ? x_offset : (row == 1 ? y_offset : z_offset);
	}

	//pad the matrix to be transformed to 4 x () matrix
	result = translation_matrix * result;
	delete[] result[row_size];
	
	result.set_row(row_size);

	return result;

}

//Scaling the matrix
template <typename T>
Matrix<T> Transformation<T>::scaling_3d(Matrix<T>& matrix, T x_factor, T y_factor, T z_factor)
{
	int row_size = matrix.get_row();
	int col_size = matrix.get_column();

	try {
		if (row_size != 3)
		{
			throw(" Each point to translate should have three coordinates for 3D transform");
		}
	}
	catch (const std::string error)
	{
		std::cerr
			<< error
			<< std::endl;
	}

	Matrix<T> result(row_size, col_size);
	for (int row = 0; row < row_size; row++)
	{
		for (int col = 0; col < col_size; col++)
		{
			result[row][col] = matrix[row][col];
		}
	}


	Matrix<T> scaling_matrix(row_size, row_size);
	for (int row = 0; row < row_size; row++)
	{
		for (int col = 0; col < row_size; col++)
		{
			if (row == col)
			{
				scaling_matrix[row][col] = row == 0 ? x_factor : (row == 1 ? y_factor : z_factor);
			}
		}
	}

	//pad the matrix to be transformed to 4 x () matrix
	result = scaling_matrix * result;

	return result;
}


//Skewing the matrix 
template <typename T>
Matrix<T> Transformation<T>::skewing_3d(Matrix<T>& matrix, char type, T factor_1, T factor_2)
{
	int row_size = matrix.get_row();
	int col_size = matrix.get_column();
	bool factor_assigned = false;

	try {
		if (row_size != 3)
		{
			throw(" Each point to translate should have three coordinates for 3D transform");
		}
	}
	catch (const std::string error)
	{
		std::cerr
			<< error
			<< std::endl;
	}

	Matrix<T> result(row_size, col_size);
	for (int row = 0; row < row_size; row++)
	{
		for (int col = 0; col < col_size; col++)
		{
			result[row][col] = matrix[row][col];
		}
	}

	Matrix<T> skew_matrix(row_size, row_size);
	for (int row = 0; row < row_size; row++)
	{
		for (int col = 0; col < row_size; col++)
		{
			if (row == col)
			{
				skew_matrix[row][col] = 1;
			}
			else
			{
				switch (type)
				{
				case 'x':
				{
					if (col == 0)
					{
						skew_matrix[row][col] = factor_assigned ? factor_2 : factor_1;
						factor_assigned = true;
					}
					break;
				}
				case 'y':
				{
					if (col == 1)
					{
						skew_matrix[row][col] = factor_assigned ? factor_2 : factor_1;
						factor_assigned = true;
					}
					break;
				}
				case 'z':
				{
					if (col == 2)
					{
						skew_matrix[row][col] = factor_assigned ? factor_2 : factor_1;
						factor_assigned = true;
					}
					break;
				}
				}
			}
		}
	}
	
	result = skew_matrix * result;
	return result;

}