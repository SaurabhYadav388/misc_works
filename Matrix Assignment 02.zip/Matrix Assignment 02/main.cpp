#include <iostream>
#include "Transformation.h"
#include "Matrix.h"

int main()
{
	Matrix<int> apple(3, 2);
	apple.enter_Element();
	apple.print();
	std::cout << "RES\n";
	Matrix<int> res(3, 2);
	res = Transformation<int>::skewing_3d(apple, 'x', 2, 3);
	res.print();
	return 0;
}