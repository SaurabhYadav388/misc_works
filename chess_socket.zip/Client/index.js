////////////////////////////////////////////Main logic from here//////////////////////////////////////////////////////////////

const socket = io();
let currentTurn = 0;

buildChessBoard();

//color board for current(default) theme
const themeSelect = document.getElementById('theme-select-board').value;
coloring(themeSelect,getPlayerId());

//Coloring the board on theme change
document.addEventListener('DOMContentLoaded', function() {
  const themeSelect = document.getElementById('theme-select-board');

  // Event listener for theme change
  themeSelect.addEventListener('change', function() {
    const selectedTheme = themeSelect.value;
    coloring(selectedTheme,getPlayerId());
  });

});

//Coloring the chat messages
document.addEventListener('DOMContentLoaded', function() {
  const themeSelectChat = document.getElementById('theme-select-board');
 
  // Event listener for theme change
  themeSelectChat.addEventListener('change', function() {
    const selectedTheme = themeSelectChat.value;
    coloringChat(selectedTheme);
  });
 
});
 
const themeSelectChat = document.getElementById('theme-select-board').value;
coloringChat(themeSelectChat);

socket.on("connect", () => {
  console.log("indexjs connected cid:", socket.id);  

  if(getPlayerId()==0)
  {
    socket.emit('createRoom',sessionStorage.getItem("createRoomId"));
  }
  else
  {
    socket.emit('joinRoom',sessionStorage.getItem("joinRoomId"));
  }
});

socket.on("startGame",()=>{
  //window.alert("start game signal");
  console.log("start game signal");
  //after game started apply drag and click to chess pieces
  applyDragEvent();
  applyClickEvent();
})

const chatTextInput = document.querySelector(".text_input");
chatTextInput.addEventListener("keypress",(e)=>{
  if(e.key==="Enter")
  {
    socket.emit("chatText",getPlayerId(),chatTextInput.value);
    chatTextInput.value="";//reset the text box
  }
})

socket.on("serverChatText",(playerId,msg)=>{
  if(playerId==getPlayerId())
  {
    console.log("Me:",msg);
    addMessage(msg,playerId);
  }
  else
  {  
    console.log("Opponent:",msg);
    addMessage(msg,playerId);
  }
})
socket.on("serverPieceMove",(playerId,pieceId,oldPosition,newPosition)=>{

  let pieceToMove=document.getElementById(oldPosition).firstChild;
  //console.log("piece to move:",pieceToMove);
  let newSquare=document.getElementById(newPosition);
  newSquare.appendChild(pieceToMove);


})
socket.on("changeTurn",(currentTurnServer)=>{
  console.log("change turn listen in client");
  currentTurn = currentTurnServer;

  // //TODO: logic to make board unclickable if not our turn
  // let boardUl=document.querySelector('ul');
  // if(currentTurn==getPlayerId())
  // {
  //   console.log("current turn:",currentTurn,"my id:",getPlayerId());
  //   if (boardUl.style.pointerEvents=== "none") {
  //     boardUl.style.pointerEvents = "auto"; // Make clickable
  //   } else {
  //     boardUl.style.pointerEvents = "none"; // Make unclickable
  //   }
  // }

});

/////////////////Main Logic Ends/////////////////////////////////////////////////




function getPlayerId()
{
    return eval(sessionStorage.getItem("playerID"));
}

function buildChessBoard()
{
  let playerId=getPlayerId();

  if(playerId==0)
  {
    //if white
    for(let row=8;row>=1;row--)
    {
      buildLogic(row,playerId);
    }
  }
  else
  { 
    //if black
    for(let row=1;row<=8;row++)
    {
      buildLogic(row,playerId);
    }
  }

  insertChessPiece();

  function buildLogic(row,playerId)
  {
    //create a div
    let rowDiv = document.createElement('div');
    rowDiv.className='div';
    rowDiv.id = `row${row}`;
    for(let i=1;i<=8;i++)
    {
      //ceate a newList ele
      let boxList=document.createElement('li');
      boxList.className = 'box';
      let colNum=(playerId==0? i:9-i);//if black column would be opposite 8,7...2,1
      boxList.id = `${row}${colNum}`;
      rowDiv.appendChild(boxList);
    }
    let boardUl=document.querySelector('ul');
    boardUl.appendChild(rowDiv);
  }

  //inserting the images
  function insertChessPiece() {
    document.querySelectorAll(".box").forEach((square) => {
      
      square.style.cursor = "pointer";

      let rowNum=eval(square.id[0]);

      if(rowNum==1 ||rowNum==2 ||rowNum==7||rowNum==8)
      {
        let imageName="";
        let pieceId="";
        
        if(rowNum == 2 )
        {  
          imageName="Wpawn";
          pieceId="pawn"+square.id[1];
        }
        else if( rowNum == 7)
        {
          imageName="Bpawn";
          pieceId="pawn"+square.id[1];//black and white same pieceid??
        }

        else if(square.id =="11" || square.id =="18")
        {  
          imageName="Wrook";
          pieceId="rook"+(square.id[1]=='1'? "1":"2");
        }
        else if(square.id =="12" || square.id =="17")
        {  
          imageName="Wknight";
          pieceId="knight"+(square.id[1]=='2'? "1":"2");
        }
        else if(square.id =="13" || square.id =="16")
        {
          imageName="Wbishop";
          pieceId="bishop"+(square.id[1]=='3'? "1":"2");
        }
        

        else if(square.id =="81" || square.id =="88")
        {  
          imageName="Brook";
          pieceId="rook"+(square.id[1]=='1'? "1":"2");
        }
        else if(square.id =="82" || square.id =="87")
        {  
          imageName="Bknight";
          pieceId="knight"+(square.id[1]=='2'? "1":"2");
        }
        else if(square.id =="83" || square.id =="86")
        {  
          imageName="Bbishop";
          pieceId="bishop"+(square.id[1]=='3'? "1":"2");
        }

        else if(square.id == "14")
        {
          imageName="Wqueen";
          pieceId="queen"
        }
        else if(square.id == "15")
        {
          imageName="Wking"
          pieceId="king"
        }
        else if(square.id == "84")
        {
          imageName="Bqueen"
          pieceId="queen"
        }
        else if(square.id == "85")
        {
          imageName="Bking"
          pieceId="king"
        }
        
        //dont know the meaning of class here
        square.innerHTML = `<img class='all-img all-pown' src='images/${imageName}.png' pieceid=${pieceId} draggable='true' alt=''>`;
        
      }
    });
  }


}


// Function to apply selected theme
function coloring(theme) {
  const boxes = document.querySelectorAll('.box');
  boxes.forEach((box, index) => {
    const getId = box.id;
    const arr = Array.from(getId);
    const aside = eval(arr.pop());
    const aup = eval(arr.shift());
    const a = aside + aup;

        if ((a) % 2 == 0) 
        {
          box.classList.remove('default-mode1', 'dark-mode1', 'light-mode1', 'red-mode1', 'blue-mode1', 'green-mode1','purple-mode1','yellow-mode1','magenta-mode1','orange-mode1');
          box.classList.add(theme +'-mode1');
        } 
        else 
        {
          box.classList.remove('dark-mode', 'light-mode', 'red-mode', 'blue-mode', 'green-mode','purple-mode','yellow-mode','magenta-mode','orange-mode');
          box.classList.add(theme + '-mode');
        }
  });
}
// Function to apply selected theme
function coloringChat(theme) {
  const messages = document.querySelectorAll('.message');
  messages.forEach((message, index) => {
    const isLeftMessage = message.classList.contains('left');
    if (isLeftMessage) {
      message.classList.remove('default-mode1', 'dark-mode1', 'light-mode1', 'red-mode1', 'blue-mode1', 'green-mode1', 'purple-mode1', 'yellow-mode1', 'magenta-mode1', 'orange-mode1');
      message.classList.add(theme + '-mode1');
    } else {
      message.classList.remove('dark-mode', 'light-mode', 'red-mode', 'blue-mode', 'green-mode', 'purple-mode', 'yellow-mode', 'magenta-mode', 'orange-mode');
      message.classList.add(theme + '-mode');
    }
  });
}

//Function for applying chesspiece drag events
function applyDragEvent() {
  const pieces = document.querySelectorAll('.box img');//maybe can also select all by giving class name  to image and queryselector
  let draggedPiece = null;
  

  // Attach drag events to all only our chess pieces
  pieces.forEach(piece => {
      //if the piece image src is (same color 0:white & 1:black) then only add to the drag and click events
      let color= (getPlayerId()==0? "W":"B");
      if(piece.getAttribute('src')[7]==color)
      {
        piece.addEventListener('dragstart', dragStart);
        piece.addEventListener('dragend', dragEnd); 
      }
          
  });

  // Attach drop event to all chessboard squares on drag drop
  const squares = document.querySelectorAll('.box');
  squares.forEach(square => {
      square.addEventListener('dragover', dragOver);
      square.addEventListener('drop', drop);
  });

  function dragStart(e) {
    draggedPiece = this;
    draggedPiece.style.border = '2px solid red';
    e.dataTransfer.setData('text/plain', ''); // Required for Firefox
}

  function dragEnd(e) {
      draggedPiece.style.border = '';
      draggedPiece = null;
      
  }

  function dragOver(e) {
      e.preventDefault();
  }

  function drop() {
      if (draggedPiece) {
        if (this.children.length === 0){
          // If the square is empty, only then append the dragged piece

          //TODO: Emit move request  to server
          let oldPosition = draggedPiece.parentNode.id;
          let newPosition = this.id;
          let pieceId= draggedPiece.getAttribute('pieceid');

          console.log(getPlayerId(),pieceId,oldPosition,newPosition);
          socket.emit("pieceMove",getPlayerId(),pieceId,oldPosition,newPosition);
        } 
      }
  }
}
//Function for applying chesspiece click events
function applyClickEvent() {
  const pieces = document.querySelectorAll('.box img');
  let clickedPiece=null;
  pieces.forEach(piece => {
    let color= (getPlayerId()==0? "W":"B");
    if(piece.getAttribute('src')[7]==color)
    {
      piece.addEventListener('click', function() {
        if (this.style.border === '2px solid red') {
          // If already highlighted, remove the highlight
          this.style.border = '';
          clickedPiece = null;
        }
        else if(clickedPiece!=null)
        {
          clickedPiece.style = '';
          //assign curr as clicked piece
          this.style.border = '2px solid red';
          clickedPiece = this;
        } 
        else {
          // If not highlighted, apply the highlight
          this.style.border = '2px solid red';
          clickedPiece = this;
      }
      });
    }
    
    //Attach drop event to all chessboard squares on click
    const squares = document.querySelectorAll('.box');
    squares.forEach(square => {
        square.addEventListener('click', function(){
          if (this.children.length === 0 && clickedPiece!=null){
            // If the square is empty, only then append the clicked piece

            //TODO: Emit move request  to server
          let oldPosition = clickedPiece.parentNode.id;
          let newPosition = this.id;
          let pieceId= clickedPiece.getAttribute('pieceid');

          console.log(getPlayerId(),pieceId,oldPosition,newPosition);

          socket.emit("pieceMove",getPlayerId(),pieceId,oldPosition,newPosition);
          clickedPiece.style.border = '';
          clickedPiece=null
          } 
        });
    });

});
 
  
}

function addMessage(message, playerId) {
  // Create a new list item for the message
  let newMessage = document.createElement('li');
  let alignment = (getPlayerId()==playerId ? "right":"left");
  newMessage.className = 'message ' + alignment;
  
  // Create a paragraph element to hold the message text
  let messageText = document.createElement('p');
  messageText.textContent = message;
  
  // Append the message text to the new list item
  newMessage.appendChild(messageText);
  
  // Find the chat container and add the new message to it
  let chatContainer = document.querySelector('.chat');
  chatContainer.insertBefore(newMessage, chatContainer.firstChild);
}






// function coloring() {
//   const color = document.querySelectorAll(".box");

//   color.forEach((color) => {
//     getId = color.id;
//     arr = Array.from(getId);
//     arr.shift();
//     aside = eval(arr.pop());
//     aup = eval(arr.shift());
//     a = aside + aup;

//     if (a % 2 == 0) {
//       color.style.backgroundColor = "rgb(32 235 239)";
//     }
//     if (a % 2 !== 0) {
//       color.style.backgroundColor = "rgb(40 180 200)";
//     }
//   });
// }
// coloring();

//function to not remove the same team element

// function reddish() {
//   document.querySelectorAll(".box").forEach((i1) => {
//     if (i1.style.backgroundColor == "blue") {
//       document.querySelectorAll(".box").forEach((i2) => {
//         if (
//           i2.style.backgroundColor == "greenyellow" &&
//           i2.innerText.length !== 0
//         ) {
//           greenyellowText = i2.innerText;

//           blueText = i1.innerText;

//           blueColor = Array.from(blueText).shift().toString();
//           greenyellowColor = Array.from(greenyellowText).shift().toString();

//           getId = i2.id;
//           arr = Array.from(getId);
//           arr.shift();
//           aside = eval(arr.pop());
//           aup = eval(arr.shift());
//           a = aside + aup;

//           if (a % 2 == 0 && blueColor == greenyellowColor) {
//             i2.style.backgroundColor = "rgb(32 235 239)";
//           }
//           if (a % 2 !== 0 && blueColor == greenyellowColor) {
//             i2.style.backgroundColor = "rgb(25 135 150)";
//           }
//         }
//       });
//     }
//   });
// }

// //reset button
// document.getElementById("reset-btn").addEventListener("click", function () {
//   location.reload();
// });

// tog = 1;

// document.querySelectorAll(".box").forEach((item) => {
//   item.addEventListener("click", function () {
//     if (
//       item.style.backgroundColor == "greenyellow" &&
//       item.innerText.length == 0
//     ) {
//       tog = tog + 1;
//     } else if (
//       item.style.backgroundColor == "greenyellow" &&
//       item.innerText.length !== 0
//     ) {
//       document.querySelectorAll(".box").forEach((i) => {
//         if (i.style.backgroundColor == "blue") {
//           blueId = i.id;
//           blueText = i.innerText;

//           document.getElementById(blueId).innerText = "";
//           item.innerText = blueText;
//           coloring();
//           insertImage();
//           tog = tog + 1;
//         }
//       });
//     }

//     getId = item.id;
//     console.log(getId);//
//     arr = Array.from(getId);
//     console.log(arr);//
//     arr.shift();
//     console.log(arr);//
//     aside = eval(arr.pop());
//     console.log(aside);//
//     arr.push("0");
//     console.log(arr);//
//     aup = eval(arr.join(""));
//     console.log(aup);//
//     a = aside + aup;
//     console.log(a);//

//     //function to display the available paths for all pieces

//     function whosTurn(toggle) {
//       // PAWN

//       if (item.innerText == `${toggle}pawn`) {
//         item.style.backgroundColor = "blue";

//         if (tog % 2 !== 0 && aup < 800) {
//           // First move for white pawns
//           if (document.getElementById(`b${a + 100}`).innerText.length == 0) {
//             document.getElementById(`b${a + 100}`).style.backgroundColor =
//               "greenyellow";
//             if (
//               document.getElementById(`b${a + 200}`).innerText.length == 0 &&
//               aup < 300
//             ) {
//               document.getElementById(`b${a + 200}`).style.backgroundColor =
//                 "greenyellow";
//             }
//           }
//           if (
//             aside < 8 &&
//             document.getElementById(`b${a + 100 + 1}`).innerText.length !== 0
//           ) {
//             document.getElementById(`b${a + 100 + 1}`).style.backgroundColor =
//               "greenyellow";
//           }
//           if (
//             aside > 1 &&
//             document.getElementById(`b${a + 100 - 1}`).innerText.length !== 0
//           ) {
//             document.getElementById(`b${a + 100 - 1}`).style.backgroundColor =
//               "greenyellow";
//           }
//         }

//         if (tog % 2 == 0 && aup > 100) {
//           // First move for black pawns
//           if (document.getElementById(`b${a - 100}`).innerText.length == 0) {
//             document.getElementById(`b${a - 100}`).style.backgroundColor =
//               "greenyellow";
//             if (
//               document.getElementById(`b${a - 200}`).innerText.length == 0 &&
//               aup > 600
//             ) {
//               document.getElementById(`b${a - 200}`).style.backgroundColor =
//                 "greenyellow";
//             }
//           }
//           if (
//             aside < 8 &&
//             document.getElementById(`b${a - 100 + 1}`).innerText.length !== 0
//           ) {
//             document.getElementById(`b${a - 100 + 1}`).style.backgroundColor =
//               "greenyellow";
//           }
//           if (
//             aside > 1 &&
//             document.getElementById(`b${a - 100 - 1}`).innerText.length !== 0
//           ) {
//             document.getElementById(`b${a - 100 - 1}`).style.backgroundColor =
//               "greenyellow";
//           }
//         }
//         // Second move for pawns
//         if (tog % 2 !== 0 && aup >= 800) {
//           if (document.getElementById(`b${a + 100}`).innerText.length == 0) {
//             document.getElementById(`b${a + 100}`).style.backgroundColor =
//               "greenyellow";
//           }
//           if (
//             aside < 8 &&
//             document.getElementById(`b${a + 100 + 1}`).innerText.length !== 0
//           ) {
//             document.getElementById(`b${a + 100 + 1}`).style.backgroundColor =
//               "greenyellow";
//           }
//           if (
//             aside > 1 &&
//             document.getElementById(`b${a + 100 - 1}`).innerText.length !== 0
//           ) {
//             document.getElementById(`b${a + 100 - 1}`).style.backgroundColor =
//               "greenyellow";
//           }
//         }
//         if (tog % 2 == 0 && aup <= 100) {
//           if (document.getElementById(`b${a - 100}`).innerText.length == 0) {
//             document.getElementById(`b${a - 100}`).style.backgroundColor =
//               "greenyellow";
//           }
//           if (
//             aside < 8 &&
//             document.getElementById(`b${a - 100 + 1}`).innerText.length !== 0
//           ) {
//             document.getElementById(`b${a - 100 + 1}`).style.backgroundColor =
//               "greenyellow";
//           }
//           if (
//             aside > 1 &&
//             document.getElementById(`b${a - 100 - 1}`).innerText.length !== 0
//           ) {
//             document.getElementById(`b${a - 100 - 1}`).style.backgroundColor =
//               "greenyellow";
//           }
//         }
//       }

//       // KING

//       if (item.innerText == `${toggle}king`) {
//         if (aside < 8) {
//           document.getElementById(`b${a + 1}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aside > 1) {
//           document.getElementById(`b${a - 1}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aup < 800) {
//           document.getElementById(`b${a + 100}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aup > 100) {
//           document.getElementById(`b${a - 100}`).style.backgroundColor =
//             "greenyellow";
//         }

//         if (aup > 100 && aside < 8) {
//           document.getElementById(`b${a - 100 + 1}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aup > 100 && aside > 1) {
//           document.getElementById(`b${a - 100 - 1}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aup < 800 && aside < 8) {
//           document.getElementById(`b${a + 100 + 1}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aup < 800 && aside > 1) {
//           document.getElementById(`b${a + 100 - 1}`).style.backgroundColor =
//             "greenyellow";
//         }

//         item.style.backgroundColor = "blue";
//       }

//       // KNIGHT

//       if (item.innerText == `${toggle}knight`) {
//         if (aside < 7 && aup < 800) {
//           document.getElementById(`b${a + 100 + 2}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aside < 7 && aup > 200) {
//           document.getElementById(`b${a - 100 + 2}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aside < 8 && aup < 700) {
//           document.getElementById(`b${a + 200 + 1}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aside > 1 && aup < 700) {
//           document.getElementById(`b${a + 200 - 1}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aside > 2 && aup < 800) {
//           document.getElementById(`b${a - 2 + 100}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aside > 2 && aup > 100) {
//           document.getElementById(`b${a - 2 - 100}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aside < 8 && aup > 200) {
//           document.getElementById(`b${a - 200 + 1}`).style.backgroundColor =
//             "greenyellow";
//         }
//         if (aside > 1 && aup > 200) {
//           document.getElementById(`b${a - 200 - 1}`).style.backgroundColor =
//             "greenyellow";
//         }

//         item.style.backgroundColor = "blue";
//       }

//       // QUEEN

//       if (item.innerText == `${toggle}queen`) {
//         for (let i = 1; i < 9; i++) {
//           if (
//             a + i * 100 < 900 &&
//             document.getElementById(`b${a + i * 100}`).innerText == 0
//           ) {
//             document.getElementById(`b${a + i * 100}`).style.backgroundColor =
//               "greenyellow";
//           } else if (
//             a + i * 100 < 900 &&
//             document.getElementById(`b${a + i * 100}`).innerText !== 0
//           ) {
//             document.getElementById(`b${a + i * 100}`).style.backgroundColor =
//               "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             a - i * 100 > 100 &&
//             document.getElementById(`b${a - i * 100}`).innerText == 0
//           ) {
//             document.getElementById(`b${a - i * 100}`).style.backgroundColor =
//               "greenyellow";
//           } else if (
//             a - i * 100 > 100 &&
//             document.getElementById(`b${a - i * 100}`).innerText !== 0
//           ) {
//             document.getElementById(`b${a - i * 100}`).style.backgroundColor =
//               "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             a + i < aup + 9 &&
//             document.getElementById(`b${a + i}`).innerText == 0
//           ) {
//             document.getElementById(`b${a + i}`).style.backgroundColor =
//               "greenyellow";
//           } else if (
//             a + i < aup + 9 &&
//             document.getElementById(`b${a + i}`).innerText !== 0
//           ) {
//             document.getElementById(`b${a + i}`).style.backgroundColor =
//               "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             a - i > aup &&
//             document.getElementById(`b${a - i}`).innerText == 0
//           ) {
//             document.getElementById(`b${a - i}`).style.backgroundColor =
//               "greenyellow";
//           } else if (
//             a - i > aup &&
//             document.getElementById(`b${a - i}`).innerText !== 0
//           ) {
//             document.getElementById(`b${a - i}`).style.backgroundColor =
//               "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             i < (900 - aup) / 100 &&
//             i < 9 - aside &&
//             document.getElementById(`b${a + i * 100 + i}`).innerText.length == 0
//           ) {
//             document.getElementById(
//               `b${a + i * 100 + i}`
//             ).style.backgroundColor = "greenyellow";
//           } else if (
//             i < (900 - aup) / 100 &&
//             i < 9 - aside &&
//             document.getElementById(`b${a + i * 100 + i}`).innerText.length !==
//               0
//           ) {
//             document.getElementById(
//               `b${a + i * 100 + i}`
//             ).style.backgroundColor = "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             i < aup / 100 &&
//             i < 9 - aside &&
//             document.getElementById(`b${a - i * 100 + i}`).innerText.length == 0
//           ) {
//             document.getElementById(
//               `b${a - i * 100 + i}`
//             ).style.backgroundColor = "greenyellow";
//           } else if (
//             i < aup / 100 &&
//             i < 9 - aside &&
//             document.getElementById(`b${a - i * 100 + i}`).innerText.length !==
//               0
//           ) {
//             document.getElementById(
//               `b${a - i * 100 + i}`
//             ).style.backgroundColor = "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             i < (900 - aup) / 100 &&
//             i < aside &&
//             document.getElementById(`b${a + i * 100 - i}`).innerText.length == 0
//           ) {
//             document.getElementById(
//               `b${a + i * 100 - i}`
//             ).style.backgroundColor = "greenyellow";
//           } else if (
//             i < (900 - aup) / 100 &&
//             i < aside &&
//             document.getElementById(`b${a + i * 100 - i}`).innerText.length !==
//               0
//           ) {
//             document.getElementById(
//               `b${a + i * 100 - i}`
//             ).style.backgroundColor = "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             i < aup / 100 &&
//             i < aside &&
//             document.getElementById(`b${a - i * 100 - i}`).innerText.length == 0
//           ) {
//             document.getElementById(
//               `b${a - i * 100 - i}`
//             ).style.backgroundColor = "greenyellow";
//           } else if (
//             i < aup / 100 &&
//             i < aside &&
//             document.getElementById(`b${a - i * 100 - i}`).innerText.length !==
//               0
//           ) {
//             document.getElementById(
//               `b${a - i * 100 - i}`
//             ).style.backgroundColor = "greenyellow";
//             break;
//           }
//         }

//         item.style.backgroundColor = "blue";
//       }

//       // BISHOP

//       if (item.innerText == `${toggle}bishop`) {
//         for (let i = 1; i < 9; i++) {
//           if (
//             i < (900 - aup) / 100 &&
//             i < 9 - aside &&
//             document.getElementById(`b${a + i * 100 + i}`).innerText.length == 0
//           ) {
//             document.getElementById(
//               `b${a + i * 100 + i}`
//             ).style.backgroundColor = "greenyellow";
//           } else if (
//             i < (900 - aup) / 100 &&
//             i < 9 - aside &&
//             document.getElementById(`b${a + i * 100 + i}`).innerText.length !==
//               0
//           ) {
//             document.getElementById(
//               `b${a + i * 100 + i}`
//             ).style.backgroundColor = "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             i < aup / 100 &&
//             i < 9 - aside &&
//             document.getElementById(`b${a - i * 100 + i}`).innerText.length == 0
//           ) {
//             document.getElementById(
//               `b${a - i * 100 + i}`
//             ).style.backgroundColor = "greenyellow";
//           } else if (
//             i < aup / 100 &&
//             i < 9 - aside &&
//             document.getElementById(`b${a - i * 100 + i}`).innerText.length !==
//               0
//           ) {
//             document.getElementById(
//               `b${a - i * 100 + i}`
//             ).style.backgroundColor = "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             i < (900 - aup) / 100 &&
//             i < aside &&
//             document.getElementById(`b${a + i * 100 - i}`).innerText.length == 0
//           ) {
//             document.getElementById(
//               `b${a + i * 100 - i}`
//             ).style.backgroundColor = "greenyellow";
//           } else if (
//             i < (900 - aup) / 100 &&
//             i < aside &&
//             document.getElementById(`b${a + i * 100 - i}`).innerText.length !==
//               0
//           ) {
//             document.getElementById(
//               `b${a + i * 100 - i}`
//             ).style.backgroundColor = "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             i < aup / 100 &&
//             i < aside &&
//             document.getElementById(`b${a - i * 100 - i}`).innerText.length == 0
//           ) {
//             document.getElementById(
//               `b${a - i * 100 - i}`
//             ).style.backgroundColor = "greenyellow";
//           } else if (
//             i < aup / 100 &&
//             i < aside &&
//             document.getElementById(`b${a - i * 100 - i}`).innerText.length !==
//               0
//           ) {
//             document.getElementById(
//               `b${a - i * 100 - i}`
//             ).style.backgroundColor = "greenyellow";
//             break;
//           }
//         }

//         item.style.backgroundColor = "blue";
//       }

//       // ROOK

//       if (item.innerText == `${toggle}rook`) {
//         for (let i = 1; i < 9; i++) {
//           if (
//             a + i * 100 < 900 &&
//             document.getElementById(`b${a + i * 100}`).innerText == 0
//           ) {
//             document.getElementById(`b${a + i * 100}`).style.backgroundColor =
//               "greenyellow";
//           } else if (
//             a + i * 100 < 900 &&
//             document.getElementById(`b${a + i * 100}`).innerText !== 0
//           ) {
//             document.getElementById(`b${a + i * 100}`).style.backgroundColor =
//               "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             a - i * 100 > 100 &&
//             document.getElementById(`b${a - i * 100}`).innerText == 0
//           ) {
//             document.getElementById(`b${a - i * 100}`).style.backgroundColor =
//               "greenyellow";
//           } else if (
//             a - i * 100 > 100 &&
//             document.getElementById(`b${a - i * 100}`).innerText !== 0
//           ) {
//             document.getElementById(`b${a - i * 100}`).style.backgroundColor =
//               "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             a + i < aup + 9 &&
//             document.getElementById(`b${a + i}`).innerText == 0
//           ) {
//             document.getElementById(`b${a + i}`).style.backgroundColor =
//               "greenyellow";
//           } else if (
//             a + i < aup + 9 &&
//             document.getElementById(`b${a + i}`).innerText !== 0
//           ) {
//             document.getElementById(`b${a + i}`).style.backgroundColor =
//               "greenyellow";
//             break;
//           }
//         }

//         for (let i = 1; i < 9; i++) {
//           if (
//             a - i > aup &&
//             document.getElementById(`b${a - i}`).innerText == 0
//           ) {
//             document.getElementById(`b${a - i}`).style.backgroundColor =
//               "greenyellow";
//           } else if (
//             a - i > aup &&
//             document.getElementById(`b${a - i}`).innerText !== 0
//           ) {
//             document.getElementById(`b${a - i}`).style.backgroundColor =
//               "greenyellow";
//             break;
//           }
//         }

//         item.style.backgroundColor = "blue";
//       }
//     }

//     // Toggling the turn

//     if (tog % 2 !== 0) {
//       document.getElementById("tog").innerText = "White's Turn";
//       whosTurn("W");
//     }
//     if (tog % 2 == 0) {
//       document.getElementById("tog").innerText = "Black's Turn";
//       whosTurn("B");
//     }

//     reddish();
//   });
// });

// // Moving the element
// document.querySelectorAll(".box").forEach((hathiTest) => {
//   hathiTest.addEventListener("click", function () {
//     if (hathiTest.style.backgroundColor == "blue") {
//       blueId = hathiTest.id;
//       blueText = hathiTest.innerText;

//       document.querySelectorAll(".box").forEach((hathiTest2) => {
//         hathiTest2.addEventListener("click", function () {
//           if (
//             hathiTest2.style.backgroundColor == "greenyellow" &&
//             hathiTest2.innerText.length == 0
//           ) {
//             document.getElementById(blueId).innerText = "";
//             hathiTest2.innerText = blueText;
//             coloring();
//             insertImage();
//           }
//         });
//       });
//     }
//   });
// });

// // Prvents from selecting multiple elements
// z = 0;
// document.querySelectorAll(".box").forEach((ee) => {
//   ee.addEventListener("click", function () {
//     z = z + 1;
//     if (z % 2 == 0 && ee.style.backgroundColor !== "greenyellow") {
//       coloring();
//     }
//   });
// });

// document.addEventListener('DOMContentLoaded', function() {
//   const boxes = document.querySelectorAll('.box');

//   let draggedPiece = null;

//   // Attach drag events to all boxes
//   boxes.forEach(box => {
//       box.addEventListener('dragstart', dragStart);
//       box.addEventListener('dragenter', dragEnter);
//       box.addEventListener('dragover', dragOver);
//       box.addEventListener('dragleave', dragLeave);
//       box.addEventListener('drop', drop);
//       box.addEventListener('dragend', dragEnd);
//   });

//   function dragStart(e) {
//       draggedPiece = this;
//       e.dataTransfer.setData('text/plain', ''); // Required for Firefox
//   }

//   function dragEnter(e) {
//       e.preventDefault();
//       this.classList.add('highlight');
//   }

//   function dragOver(e) {
//       e.preventDefault();
//   }

//   function dragLeave() {
//       this.classList.remove('highlight');
//   }

//   function drop() {
//       this.appendChild(draggedPiece);
//       this.classList.remove('highlight');
//   }

//   function dragEnd() {
//       draggedPiece = null;
//   }
// });