

class nodeCppHandler
{
    constructor()
    {
        this.cppSocket = null;
    }
    connect()
    {
        this.cppSocket = require('net').Socket();
        this.cppSocket.connect(5000,'127.0.0.1');
        this.cppSocket.setEncoding('utf-8');
        this.cppSocket.on('connect',() => {
            console.log(`C++ connected on PORT 5000`);
            this.writeSomething();
          });
          this.cppSocket.on('close', () => {
            console.log("C++ Connection closed");          
          })
    }
    writeSomething()
    {
        this.cppSocket.write("chal gyabhai");
    }
    createRoom(roomId)
    {
        //sends Request to cpp to create/initialize a game for 'roomId'
    }

    makeMove(roomId,playerId,pieceId,oldPosition,newPosition)
    {
        //sends Request to cpp to validate current move
    }


};

module.exports = nodeCppHandler;