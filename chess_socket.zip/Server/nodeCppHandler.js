

class nodeCppHandler
{

    createRoom(roomId)
    {
        //sends Request to cpp to create/initialize a game for 'roomId'
    }

    makeMove(roomId,playerId,pieceId,oldPosition,newPosition)
    {
        //sends Request to cpp to validate current move
    }


};