
var express=require('express');
var app=express();
var http=require('http');
var server=http.createServer(app);
const path =require('path');
const {Server}=require("socket.io");
const io=new Server(server, {
    cors: {
      //origin: "http://localhost:3000",
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

//////////////////////////////////////////////////////////////////////////
//Firstly this
app.get("/",(req,res)=>{
    return res.sendFile(path.resolve(__dirname,"../Client/front.html"))
})

//Secondly this(required for serving all the static file required .png,.css ,etc.)
app.use(express.static(path.resolve(__dirname,"../Client")));

//(opposite order causes to server to run index.html by default)


let roomMap={};//empty object

// Socket.IO connection handler
io.on('connection', (socket) => {
    console.log('A user connected',socket.id);
     
    socket.on("roomExistsCheck",(joinRoomId,callback)=>{
      //check if room exist of given 'joinRoomId'
      let roomExist = io.sockets.adapter.rooms.has(joinRoomId);
      callback(roomExist);

    })

    socket.on('createRoom',(createRoomId)=>
    {
      socket.join(createRoomId);
      //save the client roomid in map
      roomMap[socket.id]=createRoomId;
    });
    socket.on('joinRoom',(joinRoomId)=>
    {
      //console.log("room detail before:",io.sockets.adapter.rooms.get(joinRoomId));
      socket.join(joinRoomId);
      //save the client roomid in map
      roomMap[socket.id]=joinRoomId;
      //console.log("room detail after:",io.sockets.adapter.rooms.get(joinRoomId));

      //TODO : tell cpp backend to create room for this game

      //emit to both client in the room to start the game
      io.to(joinRoomId).emit("startGame");
    });

    socket.on("chatText",(playerId,msg)=>{
      //propagate msg to both/all of the clients in the room
      let clientRoomId=roomMap[socket.id];

      io.to(clientRoomId).emit("serverChatText",playerId,msg);
    })


    socket.on("pieceMove",(playerId,pieceId,oldPosition,newPosition,callbackMove)=>{

      //simulating delay
      setTimeout(()=>{
        //console.log("timeout end");
        //callbackMove(true);
        //if true
        let clientRoomId=roomMap[socket.id];
        io.to(clientRoomId).emit("serverPieceMove",playerId,pieceId,oldPosition,newPosition);
      },2000);

    })
    

 
    // Handle disconnection
    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});

server.listen(3000,()=>console.log('Server started at 3000'));

////////////////////////////////////////////////////////////////////////////////