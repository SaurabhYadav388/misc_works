const {ID} = require('../utils');
const {roomState} = require('./gameContext');

class NodeCppHandler
{
    constructor(io)
    {
        this.front_io = io; 
        this.axios = require('axios');
    }

    //sends Request to cpp to create/initialize a game for 'roomId'
    createRoomRequest(roomId)
    {
        const request = {
            req_id : "create_room",
            room_id : roomId
        };
        this.sendRequest(request);
    }
    //get valid Moves possible for given piece
    getValidMovesRequest(roomId,playerId,pieceId)
    {
        const request = {
            req_id : "valid_moves",
            room_id : roomId,
            player_id : playerId,
            piece_id : pieceId,
        };
        this.sendRequest(request);
        console.log("sent data mreq");
    }
    //emit to update the position of given piece 
    updatePositionRequest(roomId,playerId,pieceId,oldPosition,newPosition)
    {
        const request = {
            req_id : "update_position",
            room_id : roomId,
            player_id : playerId,
            piece_id : pieceId,
            old_position : oldPosition,
            position : newPosition
        };
        this.sendRequest(request);
    }
    //convert request object to string and emit to cpp server
    sendRequest(request)
    {
        // Send a POST request with JSON data
        this.axios.post(`http://localhost:5000`, request)
        .then(response => {
        // Handle response from the backend

        console.log('Response from backend:', response.data);
    
        this.handleResponse(response.data);
        })
        .catch(error => {
        // Handle errors
        console.error('Your Error is:', error);
        });
    }

    handleResponse(responseData)
    {
        //No need axios convert to json automatic
        //let responseObj = JSON.parse(response);
        let responseObj = responseData;

        switch (responseObj.res_id) 
        {
            case "create_room": this.createRoomResponse(responseObj);
                break;
            case "valid_moves":  this.getValidMovesResponse(responseObj);
                break;
            case "update_position":  this.updatePositionResponse(responseObj);
                break;
            default:
                console.log("Unknown response from c++!!");
        }
    }
    //handle the data/response received from cpp backend server

    createRoomResponse(responseObj)
    {
        if(responseObj.status != "SUCCESSFUL")
        {
            console.log("Create Room Unsuccessfull in c++ !!");
            return;
        }

        //initialize turn for white
        roomState[responseObj.room_id]={};
        roomState[responseObj.room_id].turn = ID.PLAYER1;
        roomState[responseObj.room_id][ID.PLAYER1] = { moveMap: {} };
        roomState[responseObj.room_id][ID.PLAYER2] = { moveMap: {} };
        
        
        //emit to both client in the room to start the game
        this.front_io.to(responseObj.room_id).emit("startGame");
       
    }
    getValidMovesResponse(responseObj)
    {
        if(responseObj.status != "SUCCESSFUL")
        {
            console.log("Response Unsuccessfull gvm from c++ !!");
            return;
        }

        this.front_io.to(responseObj.room_id).emit('serverPieceFocus',responseObj.player_id,responseObj.position_array);
        roomState[responseObj.room_id][responseObj.player_id]['moveMap'][responseObj.piece_id] = responseObj.position_array;
    }
    updatePositionResponse(responseObj)
    {
        if(responseObj.status != "SUCCESSFUL")
        {
            console.log("Response Unsuccessfull up pos from c++ !!");
            return;
        }
        this.front_io.to(responseObj.room_id).emit("serverPieceMove", responseObj.player_id, responseObj.piece_id, responseObj.old_position, responseObj.position);
        //change turn and emit to clients
        roomState[responseObj.room_id].turn = roomState[responseObj.room_id].turn == ID.PLAYER1 ? ID.PLAYER2 : ID.PLAYER1;
        this.front_io.to(responseObj.room_id).emit("changeTurn", roomState[responseObj.room_id].turn);
        
    }    
////////////////////////////////////////////////////////////////////////////////////////////

};

module.exports = NodeCppHandler;





























// sendPerData()
// {
//      // Send custom parameters periodically
//      let i=1;
//      setInterval(() => {
//         this.writeSomething(`custom data ${i++}`); // Modify data as needed
//     }, 5000);
// }

// writeSomething(data) 
// {
//     if (!this.cppSocket.destroyed) {
//         console.log("Sending custom data to C++ server");
//         this.cppSocket.write(data);
//     } else {
//         console.log("Socket is null or destroyed");
//     }
// }
