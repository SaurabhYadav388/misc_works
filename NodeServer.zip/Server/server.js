var express = require('express');
var app = express();
var http = require('http');
var server = http.createServer(app);
const path = require('path');
const { Server } = require("socket.io");
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

//////////////////////////////////////////////////////////////////////////

app.get("/", (req, res) => {
  return res.sendFile(path.resolve(__dirname, "../Client/front.html"))
})
app.use(express.static(path.resolve(__dirname, "../Client")));
/////////////////////////////////////////////////////////////////////////////

const {ID} = require('../utils');
const {roomMap,roomState} = require('./gameContext');

const NodeCppHandler = require('./nodeCppHandler');
const nodeCppHandler = new NodeCppHandler(io);

// Socket.IO connection handler
io.on('connection', (socket) => {
  console.log('A user connected', socket.id);

  socket.on("roomExistsCheck", (joinRoomId, callback) => {
    //check if room exist of given 'joinRoomId'
    const roomsMap=io.sockets.adapter.rooms;
    const room=roomsMap.get(joinRoomId);
    let roomCodeExist = io.sockets.adapter.rooms.has(joinRoomId);
    let allUsers;
    let roomSizeExist=true;
    let roomExist;
        if(room){
            allUsers=room;
        }
        let numClients=0;
        if(allUsers){
            numClients=room.size;
        }
        if(numClients==0){
          console.log("numClients: 0");
          roomSizeExist=false;
            // socket.emit('unknownGame');
        }
        else if(numClients>1){
          console.log("numClients> 1");
          roomSizeExist=false;
            // socket.emit('tooManyPlayers');
        }
        if(roomCodeExist==true && roomSizeExist==true)
          {
            roomExist=true;
          }
          else{
            roomExist=false;
          }
   
    callback(roomSizeExist);
  })
  
  socket.on('createRoom', (createRoomId) => {
    socket.join(createRoomId);
    //save the client roomid in map
    roomMap[socket.id] = createRoomId;
  });

  socket.on('joinRoom', (joinRoomId) => {
    socket.join(joinRoomId);
    //save the client roomid in map
    roomMap[socket.id] = joinRoomId;

    nodeCppHandler.createRoomRequest(joinRoomId);
  });

  socket.on("chatText", (playerId, msg) => {
    //propagate msg to both/all of the clients in the room
    let clientRoomId = roomMap[socket.id];
    io.to(clientRoomId).emit("serverChatText", playerId, msg);
  });

  socket.on("pieceFocus",(playerId, pieceId)=>{
    let clientRoomId = roomMap[socket.id];

    if (playerId != roomState[clientRoomId].turn) {
      console.log(`invalid move! not ${(playerId == ID.PLAYER1 ? "white" : "black")}'s turn!!`);
      return;
    }
    console.log("serever recv piece move from client");
    nodeCppHandler.getValidMovesRequest(clientRoomId,playerId,pieceId);

  })
  
  socket.on("pieceMove", (playerId, pieceId, oldPosition, newPosition) => {
    let clientRoomId = roomMap[socket.id];

    if (playerId != roomState[clientRoomId].turn) {
      console.log(`invalid move! not ${(playerId == ID.PLAYER1 ? "white" : "black")}'s turn!!`);
      return;
    }

    //check if in saved moveMap
    const storedValidMoves = roomState[clientRoomId]?.[playerId]?.['moveMap']?.[pieceId];
    if(storedValidMoves === undefined)
    {
      console.log("storedValidMoves is undefined");
      return;
    }
    if(storedValidMoves === null)
    {
      console.log("storedValidMoves is null");
      return;
    }

    const isCurrMoveValid = ( storedValidMoves.some(obj => JSON.stringify(obj) === JSON.stringify(newPosition)) );
    if(isCurrMoveValid == false)
    {
      console.log("invalid move position");
      return;
    }

    //emit update to cpp current movePos
    nodeCppHandler.updatePositionRequest(clientRoomId,playerId,pieceId,oldPosition,newPosition);

  });
  
  socket.on("checkOrMateStatus",(playerId)=>{
    let clientRoomId = roomMap[socket.id];
    nodeCppHandler.getCheckOrMateRequest(clientRoomId,playerId);
  })

  socket.on("undo",(playerId)=>{
    let clientRoomId = roomMap[socket.id];
    nodeCppHandler.undoMoveRequest(clientRoomId,playerId);
  })

  socket.on("redo",(playerId)=>{
    let clientRoomId = roomMap[socket.id];
    nodeCppHandler.redoMoveRequest(clientRoomId,playerId);
  })

  socket.on("resign",(playerId)=>{
    let clientRoomId = roomMap[socket.id];
    nodeCppHandler.resignRequest(clientRoomId,playerId);
  })

  socket.on("reset",(playerId)=>{
    let clientRoomId = roomMap[socket.id];
    nodeCppHandler.resetRequest(clientRoomId,playerId);
  })

  socket.on("pawnPromotion",(playerId,pieceId,position,newPieceId)=>{
    let clientRoomId = roomMap[socket.id];
    nodeCppHandler.pawnPromotionRequest(clientRoomId,playerId,pieceId,position,newPieceId);
  })

  // Handle disconnection
  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
  
});

server.listen(3000, () => console.log('Server started at 3000'));
