#include "Game.h"

Game::Game()
{

}

bool Game::create_room(std::string room_id)
{
	try
	{
		if (game_map.find(room_id) != game_map.end())
		{
			throw("Room : " + room_id + " Already Exists");
		}
		game_map[room_id] = new Board(room_id);
		return true;
	}
	catch (const std::string& error)
	{
		std::cerr
			<< error
			<< std::endl;
	}
	return false;
}

bool Game::delete_room(std::string room_id)
{
	try
	{
		if (game_map.find(room_id) == game_map.end())
		{
			throw("Room : " + room_id + " Does NOT Exist");
		}

		/*
		* de - allocate the Game State Space
		* erase the map entry
		*/
		delete game_map[room_id];
		game_map.erase(room_id);

		return true;
	}
	catch (const std::string& error)
	{
		std::cerr
			<< error
			<< std::endl;
	}

	return false;
}