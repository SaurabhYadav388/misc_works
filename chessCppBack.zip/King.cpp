#include "King.h"

std::set<std::pair<int, int>> King::get_possible_moves(std::map<std::pair<int, int>, std::pair<std::string, Chess_Piece*>>& board_map, std::string& player_id)
{

    std::set<std::pair<int, int>> valid_moves;
    std::set<std::pair<int, int>> attacked_positions;
    std::pair<int, int> next_possible_move; // of King
    std::string opponent_id = (player_id == ID::PLAYER1 ? ID::PLAYER2 : ID::PLAYER1);

    //Possible position offset for king's move
    std::vector<std::pair<int, int>> offset_group = { {1,0}, {1,1}, {0,1}, {-1,1}, {-1,0}, {-1,-1}, {0,-1}, {1,-1} };


    /*
    * Check all pieces on the board for opponent's pieces
    * Once determined, get all the positions they are attacking - [ ATTACKED_POSITIONS ]
    * We can use it to determine which place is not valid for KING
    */
    /*for (auto piece : board_map)
    {
        if (piece.second.first != player_id)
        {
            std::set<std::pair<int, int>> opponent_possible_moves = piece.second.second->get_possible_moves(board_map, opponent_id);
            attacked_positions.insert(opponent_possible_moves.begin(), opponent_possible_moves.end());
        }
    }*/


    for (auto offset : offset_group)
    {
        /*
        * Check the kings next possible move
        * If that position is being attacked, its not a valid move
        * KING cannot voluntarily move to a CHECK
        */
        next_possible_move = { position.first + offset.first , position.second + offset.second };

        if (next_possible_move.first < 1 || next_possible_move.first > 8 || next_possible_move.second < 1 || next_possible_move.second > 8) {
            continue;
        }

        else if (board_map.find(next_possible_move) == board_map.end()) {
            /*if (attacked_positions.find(next_possible_move) == attacked_positions.end())
            {
                
            */
            valid_moves.insert(next_possible_move);
            continue;
            /*else { continue; }*/
        }

        else if (board_map[next_possible_move].first != player_id) {
          /*  if (attacked_positions.find(next_possible_move) == attacked_positions.end())
            {
                
            }*/

            valid_moves.insert(next_possible_move);
            continue;
            //else { continue; }
        }
        else {
            continue;
        }
    }

    return valid_moves;
}