class nodeCppHandler
{
    constructor()
    {
        this.cppSocket = null;
    }

    connect()
    {
        this.cppSocket = new require('net').Socket();
        this.cppSocket.connect(5000,'127.0.0.1');
        this.cppSocket.setEncoding('utf-8');

        this.cppSocket.on('connect',() => {
            console.log(`C++ connected on PORT 5000`);            
        });
        this.cppSocket.on('close', () => {
            console.log("C++ Connection closed");  
            this.connect();/////////reconnect       
        });
        this.cppSocket.on('end', () => {
            console.log("C++ server disconnected(end event)");  
        });
        this.cppSocket.on('error', (error) => {
            console.error("socket error:",error);          
        });
        // this.cppSocket.on('data',(data)=>{
        //     console.log("Received from c++ data:",data);
        //     this.handleCppData(data);
        // });
    }
    //sends Request to cpp to create/initialize a game for 'roomId'
    createRoomRequest(roomId)
    {
        const request = {
            req_id : "create_room",
            room_id : roomId
        };
        this.sendRequest(request);
    }
    //get valid Moves possible for given piece
    getValidMovesRequest(roomId,playerId,pieceId)
    {
        const request = {
            req_id : "valid_moves",
            room_id : roomId,
            playerId : playerId,
            pieceId : pieceId,
        };
        this.sendRequest(request);
    }
    //emit to update the position of given piece 
    updatePositionRequest(roomId,playerId,pieceId,newPosition)
    {
        const request = {
            req_id : "position_update",
            room_id : roomId,
            playerId : playerId,
            pieceId : pieceId,
            position : newPosition
        };
        this.sendRequest(request);
    }
    //convert request object to string and emit to cpp server
    sendRequest(request)
    {
        this.cppSocket.write(JSON.stringify(request));
    }
    //handle the data/response received from cpp backend server
    // handleCppData(response)
    // {
    //     let responseObj = JSON.parse(response);

    //     switch(responseObj.res_id)
    //     {
    //         case "create_room": this.createRoomResponse(responseObj);
    //             break;

    //         case "valid_moves": this.getValidMovesResponse(responseObj);
    //             break;

    //         case "position_update": this.updatePositionResponse(responseObj);
    //             break;
            
    //         default : 
    //             console.log("Unknown response from c++!!");
    //     }
    // }

    // createRoomResponse(responseObj)
    // {
    //     if(responseObj.status != "SUCCESSFUL")
    //     {
    //         console.log("Create Room Unsuccessfull in c++ !!");
    //         return;
    //     }
    // }
    // getValidMovesResponse(responseObj)
    // {
    //     if(responseObj.status != "SUCCESSFUL")
    //     {
    //         console.log("Response Unsuccessfull gvm from c++ !!");
    //         return;
    //     }

        
    // }
    // updatePositionResponse(responseObj)
    // {
    //     if(responseObj.status != "SUCCESSFUL")
    //     {
    //         console.log("Response Unsuccessfull up pos from c++ !!");
    //         return;
    //     }
        
    // }    
////////////////////////////////////////////////////////////////////////////////////////////

};

module.exports = nodeCppHandler;





























// sendPerData()
// {
//      // Send custom parameters periodically
//      let i=1;
//      setInterval(() => {
//         this.writeSomething(`custom data ${i++}`); // Modify data as needed
//     }, 5000);
// }

// writeSomething(data) 
// {
//     if (!this.cppSocket.destroyed) {
//         console.log("Sending custom data to C++ server");
//         this.cppSocket.write(data);
//     } else {
//         console.log("Socket is null or destroyed");
//     }
// }
