
var express = require('express');
var app = express();
var http = require('http');
var server = http.createServer(app);
const path = require('path');
const { Server } = require("socket.io");
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

const nodeCppHandler = require('./nodeCppHandler');
const cppHandler = new nodeCppHandler();
cppHandler.connect();

//////////////////////////////////////////////////////////////////////////

app.get("/", (req, res) => {
  return res.sendFile(path.resolve(__dirname, "../Client/front.html"))
})

app.use(express.static(path.resolve(__dirname, "../Client")));

let roomMap = {};//empty object //maps client id to his roomid
let roomState = {};//maps roomid with its gamestate
let roomTurnMoves = {};

// Socket.IO connection handler
io.on('connection', (socket) => {
  console.log('A user connected', socket.id);

  socket.on("roomExistsCheck", (joinRoomId, callback) => {
    //check if room exist of given 'joinRoomId'
    let roomExist = io.sockets.adapter.rooms.has(joinRoomId);
    callback(roomExist);
  })
  
  socket.on('createRoom', (createRoomId) => {
    socket.join(createRoomId);
    //save the client roomid in map
    roomMap[socket.id] = createRoomId;
  });

  socket.on('joinRoom', (joinRoomId) => {
    socket.join(joinRoomId);
    //save the client roomid in map
    roomMap[socket.id] = joinRoomId;
    //create roomState(gamestate) for this roomid
    roomState[joinRoomId] = {
      turn: 0,
    };

    //TODO : tell cpp backend to create room for this game

    cppHandler.createRoomRequest(joinRoomId);
  });

  socket.on("chatText", (playerId, msg) => {
    //propagate msg to both/all of the clients in the room
    let clientRoomId = roomMap[socket.id];
    io.to(clientRoomId).emit("serverChatText", playerId, msg);
  });

  socket.on("pieceMove", (playerId, pieceId, oldPosition, newPosition) => {
    let clientRoomId = roomMap[socket.id];

    if (playerId != roomState[clientRoomId].turn) {
      console.log(`invalid move! not ${(playerId == 0 ? "white" : "black")}'s turn!!`);
      return;
    }

    //talk to cpp 
    //simulating delay
    setTimeout(() => {
      io.to(clientRoomId).emit("serverPieceMove", playerId, pieceId, oldPosition, newPosition);
      //change turn and emit to clients
      roomState[clientRoomId].turn = 1 - roomState[clientRoomId].turn
      //roomState[clientRoomId].turn = 

      io.to(clientRoomId).emit("changeTurn", roomState[clientRoomId].turn);

    }, 0);

  });

  socket.on("pieceFocus",(playerId, pieceId)=>{
    let clientRoomId = roomMap[socket.id];

    if (playerId != roomState[clientRoomId].turn) {
      console.log(`invalid move! not ${(playerId == 0 ? "white" : "black")}'s turn!!`);
      return;
    }
    //////////////////////////////
    console.log("serever recv piece move from client");
    cppHandler.getValidMovesRequest(clientRoomId,playerId,pieceId);

  })

  // Handle disconnection
  socket.on('disconnect', () => {
    console.log('User disconnected');
  });

  
});

server.listen(3000, () => console.log('Server started at 3000'));


/////////////////////////////Response Process/////////////////////////////////////

cppHandler.cppSocket.on('data', (data) => {
  console.log("Received from c++ data:", data);
  handleCppData(data);
});

function handleCppData(response)
{
  let responseObj = JSON.parse(response);

  switch (responseObj.res_id) {
    case "create_room": createRoomResponse(responseObj);
      break;

    case "valid_moves": getValidMovesResponse(responseObj);
      break;

    case "position_update": updatePositionResponse(responseObj);
      break;

    default:
      console.log("Unknown response from c++!!");
  }
}

function createRoomResponse(responseObj)
{
  if (responseObj.status != "SUCCESSFUL") {
    console.log("Create Room Unsuccessful in c++ !! sockid:");
    return;
  }
  
  //emit to both client in the room to start the game
  io.to(responseObj.room_id).emit("startGame");
}
function getValidMovesResponse(responseObj)
{
  console.log("recv mreq resp");
  if (responseObj.status != "SUCCESSFUL") {
    console.log("Response Unsuccessful gvm from c++ !!");
    return;
  }

  roomTurnMoves[responseObj["room_id"]].validMoves.pieceId=responseObj.array;///////////////////////////
  console.log("array from c++ is:",responseObj.array);//////////////

  let posArr = [];
  for (let i=0;i<responseObj.array.length;i++)
  {
    let pos="";
    pos+=responseObj.array[i].x;
    pos+=responseObj.array[i].y;
    console.log("pos:",pos);
  }

  ///TODO: should need to emit to only one req. client
  io.to(responseObj.room_id).emit("serverPieceFocus",playerId,pieceId,posArr);



}
function updatePositionResponse(responseObj)
{
  if (responseObj.status != "SUCCESSFUL") {
    console.log("Response Unsuccessful up pos from c++ !!");
    return;
  }

}

/////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////