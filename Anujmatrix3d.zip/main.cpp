#include<iostream>
#include"Matrice.h"
#include<vector>
#include"Translation.h"
#include"Scaling.h"

int main() {

    int choice = 0; int points;

    double tx, ty, tz, sx, sy, sz, angle, x, y, z, scalar;

    do {

        std::cout << "Select a transformation:" << std::endl;
        std::cout << "1. Translation" << std::endl;
        std::cout << "2. Scaling" << std::endl;
        std::cout << "3. Scalar Multiplciation" << std::endl;
        std::cout << "4. Transpose" << std::endl;
        std::cout << "5. Rotation" << std::endl;
        std::cout << "6. Exit" << std::endl;
        std::cout << "-----------------------------------------------------------------------------------------------------------------------" << std::endl;

        std::cin >> choice;

        switch (choice) {

        case 1: {

            std::cout << "Enter the number of 3d points to be Translated: " << std::endl;
            std::cin >> points;
      
            Translation t(points);
            std::cout << "Enter translation values (tx, ty, tz): " << std::endl;
            std::cin >> tx >> ty >> tz;
            t.translation(tx, ty, tz);
            break;
        }

              case 2: {

                std::cout << "Enter the number of 3d points to be Translated: " << std::endl;
                std::cin >> points;

                Scaling s(points);
                std::cout << "Enter scaling values (sx, sy, sz): "<<std::endl;
                std::cin >> sx >> sy >> sz;
                s.scaling(sx, sy, sz);
                break;
              }

              case 3: {

                  int row , col;                       //r is for rows and c is for columns

                  std::cout << "Enter the value of rows of Matrix 1-->" << std::endl;
                  std::cin >> row;

                  std::cout << "Enter the value of columns of Matrix 1-->" << std::endl;
                  std::cin >> col;

                  Matrice matrix_1(row, col);
                  std::cout << "Enter the elements of Matrix 1:" << std::endl;
                  matrix_1.set_value();
                  std::cout << "-----------------------------------------------------------------------------------------------------------------------" << std::endl;
                  std::cout << "Enter the value for Scaler multiplication" << std::endl;
                  std::cin >> scalar;
                  (matrix_1* scalar).print_it();
                  break;
              }

              case 4: {

                  int row, col;                       //r is for rows and c is for columns

                  std::cout << "Enter the value of rows of Matrix 1-->" << std::endl;
                  std::cin >> row;

                  std::cout << "Enter the value of columns of Matrix 1-->" << std::endl;
                  std::cin >> col;

                  Matrice matrix_1(row, col);
                  std::cout << "Enter the elements of Matrix 1:" << std::endl;
                  matrix_1.set_value();
                  std::cout << "-----------------------------------------------------------------------------------------------------------------------" << std::endl;
                  std::cout << "The transposed Matrix is: " << std::endl;
                  
                  (matrix_1.transpose(matrix_1)).print_it();
                  std::cout << "-----------------------------------------------------------------------------------------------------------------------" << std::endl;

                  break;
              }
              case 5: {
                std::cout << "Enter rotation angle (degrees) and axis (x, y, z): ";
                std::cin >> angle >> x >> y >> z;
                //Rotation rotation;
                //.rotate(angle, x, y, z);
                //rotation.print();
                break;
              }

              case 6:
                return 0;

        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
        }

    } while (choice != 6);

}